package com.sea.test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

import msg.PublishMsg;
import msg.RegisterMsg;
import msg.ServeiceInstanceInfo;
import msg.ServiceDefineInfo;
import msg.ZkInfo;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.jboss.netty.bootstrap.ServerBootstrap;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelHandler;
import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;
import org.jboss.netty.handler.codec.string.StringDecoder;
import org.jboss.netty.handler.codec.string.StringEncoder;

import role.Publisher;
import role.Registeror;
import core.ZkClient;

public class Server {

	public void start(ZkInfo zkInfo) throws Exception {
		ZkClient zkClient = new ZkClient(zkInfo.getConnectAddr(), zkInfo.getTimeout(), new ZkWatch());
		createService(zkInfo, zkClient);
		registerServer(zkInfo, zkClient);
		// subscriber(zkClient);

		Thread.sleep(1000 * 60 * 10);

	}

	private void registerServer(ZkInfo zkInfo, ZkClient zkClient) throws Exception {
		try {
			Registeror registeror = new Registeror(zkInfo.getServiceName(), zkClient);
			RegisterMsg registerMsg = new RegisterMsg();
			ServeiceInstanceInfo serveiceInstanceInfo = new ServeiceInstanceInfo();
			serveiceInstanceInfo.setIp("1.12.2.154");
			serveiceInstanceInfo.setPort(80);
			serveiceInstanceInfo.setServiceName("test");
			serveiceInstanceInfo.setState("true");
			serveiceInstanceInfo.setWeightValue(20);
			registerMsg.setServeiceInstanceInfo(serveiceInstanceInfo);
			registeror.registerService(registerMsg);
			// Thread.sleep(1000*60*1);
		} catch (KeeperException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void createService(ZkInfo zkInfo, ZkClient zkClient) throws IOException {
		try {
			Publisher publisher = new Publisher(zkInfo.getServiceName(), zkClient);
			ServiceDefineInfo serviceDefineInfo = new ServiceDefineInfo();
			serviceDefineInfo.setDescription("测试服务");
			serviceDefineInfo.setFailstrage("fail");
			serviceDefineInfo.setProtol("frame");
			serviceDefineInfo.setProxyClass("com.baidu.usercenter.api.UserService");
			serviceDefineInfo.setRoutestrage("round");
			serviceDefineInfo.setServicename(zkInfo.getServiceName());
			serviceDefineInfo.setTimeout(1000);
			serviceDefineInfo.setVersion("1");
			PublishMsg publishMsg = new PublishMsg("zhanghai", serviceDefineInfo);
			publisher.publishService(publishMsg);
		} catch (KeeperException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 启动服务实例
	 */
	private void onLineService() {

		ServerBootstrap bootstrap = new ServerBootstrap(new NioServerSocketChannelFactory(
				Executors.newCachedThreadPool(), Executors.newCachedThreadPool()));

		// Set up the default event pipeline.
		bootstrap.setPipelineFactory(new ChannelPipelineFactory() {
			@Override
			public ChannelPipeline getPipeline() throws Exception {
				return Channels.pipeline(new StringDecoder(), new StringEncoder(), new ServerHandler());
			}
		});

		// Bind and start to accept incoming connections.
		Channel bind = bootstrap.bind(new InetSocketAddress(8000));
		System.out.println("Server已经启动，监听端口: " + bind.getLocalAddress() + "， 等待客户端注册。。。");

	}

	// TODO:自检

	class ZkWatch implements Watcher {

		public void process(WatchedEvent event) {

		}

	}

	private static class ServerHandler extends SimpleChannelHandler {
		@Override
		public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) throws Exception {
			if (e.getMessage() instanceof String) {
				String message = (String) e.getMessage();
				System.out.println("Client发来:" + message);

				e.getChannel().write("Server已收到刚发送的:" + message);

				System.out.println("\n等待客户端输入。。。");
			}

			super.messageReceived(ctx, e);
		}

		@Override
		public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) throws Exception {
			super.exceptionCaught(ctx, e);
		}

		@Override
		public void channelConnected(ChannelHandlerContext ctx, ChannelStateEvent e) throws Exception {
			System.out.println("有一个客户端注册上来了。。。");
			System.out.println("Client:" + e.getChannel().getRemoteAddress());
			System.out.println("Server:" + e.getChannel().getLocalAddress());
			System.out.println("\n等待客户端输入。。。");
			super.channelConnected(ctx, e);
		}
	}

	public static void main(String[] args) throws Exception {
		ZkInfo zkInfo = new ZkInfo();
		zkInfo.setConnectAddr("127.0.0.1:2181");
		zkInfo.setTimeout(1000);
		zkInfo.setServiceName("test");
		Server dsframe = new Server();
		try {
			dsframe.start(zkInfo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
