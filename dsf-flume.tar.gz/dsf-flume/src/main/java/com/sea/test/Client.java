package com.sea.test;

import java.io.IOException;

import msg.ZkInfo;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

import role.Subscriber;

import com.baidu.usercenter.api.UserService;

import core.ZkClient;

public class Client
{

	public void start(ZkInfo zkInfo) throws IOException
	{
		ZkClient zkClient = new ZkClient(zkInfo.getConnectAddr(), zkInfo.getTimeout(), new ZkWatch());
//		createService( zkInfo,  zkClient);
//		  registerServer(zkInfo, zkClient);
		  subscriber(zkClient);
		
	}

	private void subscriber(ZkClient zkClient) throws IOException
	{
		try
		{
			Subscriber subscriber = new Subscriber("test" ,zkClient);
			GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
			subscriber.subscribeService("testapp", "zhanghai", genericObjectPoolConfig);
			UserService o = (UserService)subscriber.choseClient();
			
			System.out.println(o.getUserId("1"));
			
			Thread.sleep(1000*60*60);
			
		} catch (KeeperException | InterruptedException e)
		{
			e.printStackTrace();
		}
	}


	class ZkWatch implements Watcher
	{

		public void process(WatchedEvent event)
		{
			
		}

	}

	public static void main(String[] args)
	{
		ZkInfo zkInfo = new ZkInfo();
		zkInfo.setConnectAddr("127.0.0.1:2181");
		zkInfo.setTimeout(1000);
		zkInfo.setServiceName("test");
		Client dsframe = new Client();
		try
		{                   
			dsframe.start(zkInfo);
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}

}
