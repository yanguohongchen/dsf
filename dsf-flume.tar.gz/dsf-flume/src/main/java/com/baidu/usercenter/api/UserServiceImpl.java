package com.baidu.usercenter.api;

import org.apache.avro.AvroRemoteException;

public class UserServiceImpl implements UserService {

	public long getUserId(CharSequence sid) throws AvroRemoteException {
		
		return 0;
	}

}
